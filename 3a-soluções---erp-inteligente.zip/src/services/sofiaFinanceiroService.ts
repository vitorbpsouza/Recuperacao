import { GoogleGenAI, Type } from "@google/genai";
import { Repasse, SofiaFinancialRecommendation, Recuperador, Ativo } from "../types";

let aiInstance: GoogleGenAI | null = null;

const getAiInstance = () => {
  if (!aiInstance) {
    const apiKey = typeof process !== 'undefined' ? process.env.GEMINI_API_KEY : '';
    if (!apiKey) return null;
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
};

export const analyzeFinancialPriorities = async (
  repasses: Repasse[],
  recuperadores: Recuperador[],
  ativos: Ativo[]
): Promise<SofiaFinancialRecommendation[]> => {
  const ai = getAiInstance();
  
  if (!ai) {
    console.warn("GEMINI_API_KEY não configurada ou inacessível. Usando análise simulada.");
    return simulateAnalysis(repasses);
  }

  try {
    const pendingRepasses = repasses.filter(r => r.status === 'Pendente');
    
    if (pendingRepasses.length === 0) return [];

    const context = pendingRepasses.map(r => {
      const rec = recuperadores.find(rec => rec.id === r.recuperadorId);
      const ativo = ativos.find(a => a.id === r.ativoId);
      return {
        id: r.id,
        valor: r.valor,
        data: r.data,
        tipo: r.tipo,
        recuperador: rec?.nome,
        recuperadorScore: rec?.score,
        ativoPlaca: ativo?.placa,
        ativoStatus: ativo?.status
      };
    });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analise os seguintes repasses financeiros pendentes e sugira prioridades de pagamento.
      Considere:
      1. Valor (repasses maiores podem ter maior impacto).
      2. Tempo de atraso (data do repasse).
      3. Risco de cancelamento (baseado no status do ativo e score do recuperador).
      4. Importância do recuperador (score).

      Dados dos repasses: ${JSON.stringify(context)}

      Retorne um JSON seguindo exatamente este schema:
      Array<{
        repasseId: string,
        prioridade: "Baixa" | "Média" | "Alta" | "Crítica",
        justificativa: string,
        riscoCancelamento: number (0-100)
      }>`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              repasseId: { type: Type.STRING },
              prioridade: { type: Type.STRING },
              justificativa: { type: Type.STRING },
              riscoCancelamento: { type: Type.NUMBER }
            },
            required: ["repasseId", "prioridade", "justificativa", "riscoCancelamento"]
          }
        }
      }
    });

    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Erro na análise da SOFIA:", error);
    return simulateAnalysis(repasses);
  }
};

const simulateAnalysis = (repasses: Repasse[]): SofiaFinancialRecommendation[] => {
  return repasses
    .filter(r => r.status === 'Pendente')
    .map(r => ({
      repasseId: r.id,
      prioridade: r.valor > 5000 ? 'Alta' : 'Média',
      justificativa: "Análise baseada em valor e tempo de processamento padrão.",
      riscoCancelamento: Math.floor(Math.random() * 30)
    }));
};
