import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { SofiaPanel } from './components/SofiaPanel';
import { Dashboard } from './components/Dashboard';
import { AtivosModule } from './components/AtivosModule';
import { RecuperadoresModule } from './components/RecuperadoresModule';
import { DistribuicaoModule } from './components/DistribuicaoModule';
import { OperacoesModule } from './components/OperacoesModule';
import { BancosModule } from './components/BancosModule';
import { RelatoriosModule } from './components/RelatoriosModule';
import { EnriquecimentoModule } from './components/EnriquecimentoModule';
import { FinanceiroModule } from './components/FinanceiroModule';
import { motion, AnimatePresence } from 'framer-motion';
import { MOCK_ATIVOS } from './constants';
import { Ativo, Notification } from './types';

import { ToastContainer, showToast } from './components/Toast';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSofiaOpen, setIsSofiaOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [ativos, setAtivos] = useState<Ativo[]>(MOCK_ATIVOS);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [selectedAtivoId, setSelectedAtivoId] = useState<string | null>(null);

  const addNotification = (notif: Omit<Notification, 'id' | 'data' | 'lida'>) => {
    const newNotif: Notification = {
      ...notif,
      id: Math.random().toString(36).substr(2, 9),
      data: new Date().toISOString(),
      lida: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, lida: true } : n));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  useEffect(() => {
    // Simular carregamento inicial do sistema
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return (
        <Dashboard 
          ativos={ativos} 
          onViewDetails={(id) => {
            setSelectedAtivoId(id);
            setActiveTab('ativos');
          }}
        />
      );
      case 'ativos': return (
        <AtivosModule 
          ativos={ativos} 
          setAtivos={setAtivos} 
          initialSelectedId={selectedAtivoId}
          onClearSelection={() => setSelectedAtivoId(null)}
        />
      );
      case 'recuperadores': return <RecuperadoresModule />;
      case 'distribuicao': return (
        <DistribuicaoModule 
          ativos={ativos} 
          setAtivos={setAtivos} 
          onViewDetails={(id) => {
            setSelectedAtivoId(id);
            setActiveTab('ativos');
          }}
        />
      );
      case 'operacoes': return <OperacoesModule ativos={ativos} />;
      case 'bancos': return <BancosModule />;
      case 'enriquecimento': return <EnriquecimentoModule />;
      case 'financeiro': return (
        <FinanceiroModule 
          onPaymentPaid={(repasse, recuperador) => {
            addNotification({
              titulo: 'Repasse Pago',
              mensagem: `O repasse #${repasse.id} para ${recuperador?.nome} foi marcado como pago.`,
              tipo: 'pagamento',
              prioridade: 'media'
            });
          }} 
        />
      );
      case 'relatorios': return <RelatoriosModule ativos={ativos} />;
      case 'sofia': return <RelatoriosModule ativos={ativos} />; // Placeholder for SOFIA detailed view
      default: return <Dashboard ativos={ativos} />;
    }
  };

  const getActiveTabLabel = () => {
    const labels: Record<string, string> = {
      dashboard: 'Dashboard Executivo',
      ativos: 'Gestão de Ativos',
      recuperadores: 'Recuperadores',
      distribuicao: 'Distribuição e Campo',
      operacoes: 'Operações Internas',
      bancos: 'Bancos e Clientes',
      enriquecimento: 'Enriquecimento de Dados',
      financeiro: 'Gestão Financeira e Repasses',
      relatorios: 'Relatórios e Inteligência',
      sofia: 'SOFIA — Central',
      config: 'Configurações'
    };
    return labels[activeTab] || 'Dashboard';
  };

  if (isLoading) {
    return (
      <div className="h-screen w-full bg-slate-950 flex flex-col items-center justify-center space-y-6">
        <div className="w-20 h-20 bg-blue-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-600/40 animate-bounce">
          <span className="text-white font-bold text-3xl">3A</span>
        </div>
        <div className="flex flex-col items-center space-y-2">
          <h2 className="text-white font-bold text-xl tracking-tight">Iniciando 3A Soluções</h2>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
            <p className="text-slate-500 text-xs font-medium uppercase tracking-widest">SOFIA está carregando os dados...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-blue-500/30">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 flex flex-col min-w-0">
        <Header 
          activeTabLabel={getActiveTabLabel()} 
          notifications={notifications}
          onMarkAsRead={markNotificationAsRead}
          onClearAll={clearNotifications}
        />
        
        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                {renderContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </main>

      <SofiaPanel isOpen={isSofiaOpen} setIsOpen={setIsSofiaOpen} ativos={ativos} />
      <ToastContainer />
    </div>
  );
}
